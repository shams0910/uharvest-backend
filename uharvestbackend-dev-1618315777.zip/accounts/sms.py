import requests

def sms_confirmation():
	pass