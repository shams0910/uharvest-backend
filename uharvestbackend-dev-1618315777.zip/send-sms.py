import requests
# import json
from core.models import Crop

crops = Crop.objects.raw('SELECT task.id, task.title, crop.id as crop_id, crop.year, \
	crop.crop_choice_id, cropchoice.name as cropchoice_name, contour.number as contour_number, contour.id as contour_id, contour.farmer_id, account.phone, account.first_name, account.last_name\
	from core_crop as crop\
	left join locations_contour as contour on contour.id=crop.contour_id\
	left join accounts_account as account on account.id=contour.farmer_id\
	left join core_cropchoice as cropchoice on crop.crop_choice_id=cropchoice.id\
	join core_task as task on task.crop_choice_id=crop.crop_choice_id\
	where crop.year=2021 order by contour.farmer_id, contour.number, task.id')

crops_dict = list(crop.__dict__ for crop in crops)
states = list(crop.pop('_state') for crop in crops_dict)

print(crops_dict)
















# data = [
#   {
#   	""
#     "phone":"998998313787", 
#     "text":"тестовое смс 1",
#   },
# ] 

# apiKey = 'nIWIXRKDQNyKD71qxTxTCw=='
# response = requests.post(f'https://platform.clickatell.com/messages/http/send?apiKey={apiKey}&to=48792962084&content=Test+message+text')

# print(response.status_code)
# data  = response
# print(data)
# print(json.dumps(data, sort_keys=True, indent=4))

